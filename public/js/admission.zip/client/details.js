var client_details = {
    settings: {
        clientPetAjaxUrl: '',
        branchAjaxUrl: '',
        clientId:'',
        clientPetAjaxForm: '',
        clientPaymentAjaxUrl: '',
        clientReimbursedPaymentAjaxUrl: ''
    },
    init: function() {
        client_details.initPetDataTable();
        client_details.bindModal();
    },
    initPetDataTable: function() {

        var callBack = function() {
        };

        client_details.dataListPet = $('#pet-datalist').DataTable({
            'processing': true,
            'serverSide': true,
            "lengthChange": false,
            "pageLength": 20,
            'ajax': {
                'url': client_details.settings.clientPetAjaxUrl,
                'data': function(d) {
                    d.url = global.settings.url;
                    d.clientId = client_details.settings.clientId; 
                }
            },
            'deferRender': true,
            'columnDefs': [
                { 'orderable': false, 'targets': 4 },
                { 'searchable': false, 'targets': 4 }
            ],
            drawCallback: function() {
                callBack();
            },
            responsive: {
                details: {
                    renderer: function( api,rowIdx ) {
                        return global.dataTableResponsiveCallBack(api, rowIdx, callBack);
                    }
                }
            }
        });

        client_details.dataListPAyments = $('#payment-datalist').DataTable({
            'processing': true,
            'serverSide': true,
            "lengthChange": false,
            "pageLength": 20,
            'ajax': {
                'url': client_details.settings.clientPaymentAjaxUrl,
                'data': function(d) {
                    d.url = global.settings.url;
                    d.clientId = client_details.settings.clientId; 

                }
            },
            'deferRender': true,
            'columnDefs': [
                { 'orderable': false, 'targets': null },
                { 'searchable': false, 'targets': null }
            ],
            drawCallback: function() {
                callBack();
            },
            responsive: {
                details: {
                    renderer: function( api,rowIdx ) {
                        return global.dataTableResponsiveCallBack(api, rowIdx, callBack);
                    }
                }
            }
        });

        client_details.reimbursedPayments = $('#reimbursed-datalist').DataTable({
            'processing': true,
            'serverSide': true,
            "lengthChange": false,
            "pageLength": 20,
            'ajax': {
                'url': client_details.settings.clientReimbursedPaymentAjaxUrl,
                'data': function(d) {
                    d.url = global.settings.url;
                    d.clientId = client_details.settings.clientId; 

                }
            },
            'deferRender': true,
            'columnDefs': [
                { 'orderable': false, 'targets': null },
                { 'searchable': false, 'targets': null }
            ],
            drawCallback: function() {
                callBack();
            },
            responsive: {
                details: {
                    renderer: function( api,rowIdx ) {
                        return global.dataTableResponsiveCallBack(api, rowIdx, callBack);
                    }
                }
            }
        });

        $('.content-container').removeClass('has-loading');
        $('.content-container-content').removeClass('hide');
    },
 
    bindModal: function (){
        
        $('.href-modal').unbind('click').bind('click',function(){
          
            $.ajax({
              url: client_details.settings.clientPetAjaxForm,
              type: 'POST',
              data: { clientId: client_details.settings.clientId },
              beforeSend: function(){
                $(".modal-content").html('');
                  
              },
              success: function(r){
                if(r.success){
          
                  $(".modal-content").html(r.html);
                  $('#modal').modal('show');
                }
              }
            });
        });
    }

};