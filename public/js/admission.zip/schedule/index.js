var schedule = {
    settings: {
        ajaxUrl: ''
    },
    init: function() {
        schedule.initDataTable();

        $('#startDate,#endDate').unbind('change').bind('change',function(){

            schedule.dataList.draw();
        });
    },
    initDataTable: function() {

        var callBack = function() {
        };

        schedule.dataList = $('#schedule-datalist').DataTable({
            'order': [[4, 'ASC']],
            'processing': true,
            'serverSide': true,
            "lengthChange": false,
            "pageLength": 20,
            'ajax': {
                'url': schedule.settings.ajaxUrl,
                'data': function(d) {
                    d.url = global.settings.url;
                    d.startDate = $('#startDate').val();
                    d.endDate = $('#endDate').val();
                }
            },
            'deferRender': true,
            'columnDefs': [
                { 'orderable': false, 'targets': 5 },
                { 'searchable': false, 'targets': 5 }
            ],
            createdRow: function( row, data, dataIndex ) {
                // Set the data-status attribute, and add a class
               var dataType =  $( row ).find('td:eq(5)').find('.table-btn').attr('data-type');

               if(dataType == 'follow-up'){
                
                    $( row ).css('background-color' , '#7bc234');
               } else {

               }
            },
            drawCallback: function() {
                callBack();
            },
            responsive: {
                details: {
                    renderer: function( api,rowIdx ) {
                        return global.dataTableResponsiveCallBack(api, rowIdx, callBack);
                    }
                }
            }
        });

        $('.content-container').removeClass('has-loading');
        $('.content-container-content').removeClass('hide');
    }
};