var pet_details = {
    settings: {
        petId: '',
        medicalRecordAjaxListUrl: ''
    },
    init: function() {
        pet_details.initDatatable();
    },
    initDatatable: function() {

        var callBack = function() {
        };

        pet_details.dataListPet = $('#medicalRecords-datalist').DataTable({
            'responsive': true,
            'processing': true,
            'serverSide': true,
            "lengthChange": false,
            "pageLength": 20,
            'ajax': {
                'url': pet_details.settings.medicalRecordAjaxListUrl,
                'data': function(d) {
                    d.url = global.settings.url;
                    d.petId = pet_details.settings.petId; 
                }
            },
            'deferRender': true,
            'columnDefs': [
                { 'orderable': false, 'targets': 7 },
                { 'searchable': false, 'targets': 7 }
            ],
            drawCallback: function() {
                callBack();
            },
            responsive: {
                details: {
                    renderer: function( api,rowIdx ) {
                        return global.dataTableResponsiveCallBack(api, rowIdx, callBack);
                    }
                }
            }
        });


        $('.content-container').removeClass('has-loading');
        $('.content-container-content').removeClass('hide');
    }

};